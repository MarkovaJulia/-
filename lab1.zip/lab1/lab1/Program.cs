﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
namespace lab1
{
    interface Celcium
    {
        int getTemp();
    }
    class DeviceCelcium : Celcium
    {
        public int getTemp()
        {
            return 37;
        }
    }
    class DeviceFahrenheit
    {
        public int getFahrTemp()
        {
            return 100;
        }
    }
    class FahrenheitAdapter : Celcium
    {
        DeviceFahrenheit fahr;
        public FahrenheitAdapter(DeviceFahrenheit fahr)
        {
            this.fahr = fahr;
        }
        public int getTemp()
        {
            return (fahr.getFahrTemp() - 32) * 5 / 9;
        }
    }
    class TempReader
    {
        public int readTemp(Celcium cel)
        {
            return cel.getTemp();
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Celcium c1 = new DeviceCelcium();
            DeviceFahrenheit fahrDevice = new DeviceFahrenheit();
            Celcium c2 = new FahrenheitAdapter(fahrDevice);

            Console.WriteLine(c1.getTemp() + ", " + c2.getTemp());
            Console.ReadLine();
        }
    }
} 

*/

  namespace lab2
{
    abstract class AbstractEngine
    {
        abstract public string getMaxSpeed();
    }
    class FordEngine : AbstractEngine
    {
        public override string getMaxSpeed()
        {
            return "форд 200";
        }
    }
    class AudiEngine : AbstractEngine
    {
        public override string getMaxSpeed()
        {
            return "ауди 300";
        }
    }
    abstract class AbstractKuzov
    {
        abstract public string getKuzov();
    }
    class SedanKuzov : AbstractKuzov
    {
        public override string getKuzov()
        {
            return "sedan";
        }
    }
    class CrossoverKuzov : AbstractKuzov
    {
        public override string getKuzov()
        {
            return "kross";
        }
    }
    abstract class AbstractCar
    {
        public abstract string getMaxSpeed(AbstractEngine engine);
        public abstract string getKuzov(AbstractKuzov kuzov);

    }
    class FordCar : AbstractCar
    {
        public override string getMaxSpeed(AbstractEngine engine)
        {
            return "Машина Форд с двигателем" + engine.getMaxSpeed(); 
        }

        public override string getKuzov(AbstractKuzov kuzov)
        {
            return " Форд с кузовом " + kuzov.getKuzov();
        }
    }
    class AudiCar : AbstractCar
    {
        public override string getMaxSpeed(AbstractEngine engine)
        {
            return "Машина Ауди с двигателем " + engine.getMaxSpeed();
        }
        public override string getKuzov(AbstractKuzov kuzov)
        {
            return " Ауди с кузовом " + kuzov.getKuzov();
        }
    }

    abstract class CarFactory
    {
        public abstract AbstractEngine createEngine();
        public abstract AbstractCar createCar();
        public abstract AbstractKuzov createKuzov();

    }
    class FordFactory : CarFactory
    {
        public override AbstractEngine createEngine()
        {
            return new FordEngine();
        }

        public override AbstractCar createCar()
        {
            return new FordCar();
        }

        public override AbstractKuzov createKuzov()
        {
            return new SedanKuzov();
        }
    }
    class AudiFactory : CarFactory
    {
        public override AbstractEngine createEngine()
        {
            return new AudiEngine();
        }

        public override AbstractCar createCar()
        {
            return new AudiCar();
        }

        public override AbstractKuzov createKuzov()
        {
            return new CrossoverKuzov();
        }
    }
    class AudiCarWithFordEngineFactory : CarFactory
    {
        public override AbstractEngine createEngine()
        {
            return new FordEngine();
        }

        public override AbstractCar createCar()
        {
            return new AudiCar();
        }

        public override AbstractKuzov createKuzov()
        {
            return new SedanKuzov();
        }
    }
    class FordCarWithAudiEngineFactory : CarFactory
    {
        public override AbstractEngine createEngine()
        {
            return new AudiEngine();
        }

        public override AbstractCar createCar()
        {
            return new FordCar();
        }

        public override AbstractKuzov createKuzov()
        {
            return new SedanKuzov();
        }
    }

    class Client
    {
        CarFactory factory;
        public Client(CarFactory factory)
        {
            this.factory = factory;
        }

        public string createMachine()
        {
            AbstractCar car = factory.createCar();
            AbstractEngine engine = factory.createEngine();
            AbstractKuzov kuzov = factory.createKuzov();
            return car.getMaxSpeed(engine) + car.getKuzov(kuzov);

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            CarFactory fordFactory = new FordFactory();
            CarFactory audiFactory = new AudiFactory();
            CarFactory fordCarWithAudiEngineFactory = new FordCarWithAudiEngineFactory();
            CarFactory audiCarWithFordEngineFactory = new AudiCarWithFordEngineFactory();

            Client c1 = new Client(fordFactory);
            Client c2 = new Client(audiFactory);
            Client c3 = new Client(fordCarWithAudiEngineFactory);
            Client c4 = new Client(audiCarWithFordEngineFactory);

            Console.WriteLine(c1.createMachine());
            Console.WriteLine(c2.createMachine());
            Console.WriteLine(c3.createMachine());
            Console.WriteLine(c4.createMachine());

            Console.ReadLine();
        }
    }
}
